/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progicetask4;

/**
 *
 * @author Student
 */
import java.util.Scanner;
public class PROGIceTask4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String password;
        
        // Prompt the user for their password
        System.out.println("Enter your password");
        password = input.nextLine();
        if (!strongPassword(password)) {
                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must:");
                System.out.println("- Be at least 8 characters long");
                System.out.println("- Contain at least one capital letter");
                System.out.println("- Contain at least one number");
                System.out.println("- Contain at least one special character\n");
            } else{
        System.out.println("Password successfully captured");
        input.close();
        }
    }

    
    //Create a method to check if the password is strong
    //The password must contain an capital letter, a number, a special character and must be 8 or more characters
    private static boolean strongPassword(String password){
        if( password.length()<8){
            return false;
        }
       boolean hasCapitalLetter = false;
       boolean hasNumber = false;
       boolean hasSpecialCharacter = false;
       
       //Create a loop that will go through the password characters
       for (int i=0; i< password.length(); i++){
           char character = password.charAt(i);
           
           if(Character.isUpperCase(character)){
               hasCapitalLetter = true;
           }
           
           if(Character.isDigit(character)){
               hasNumber = true;
           }
           
           if(!Character.isLetterOrDigit(character)){
               hasSpecialCharacter = true;
           }
       }
       
       return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }
}
